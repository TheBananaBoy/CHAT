import React from 'react';
import ReactDOM from 'react-dom';
import SettingsComponent from './SettingsComponent';

ReactDOM.render(<SettingsComponent />, document.getElementById('root'));
